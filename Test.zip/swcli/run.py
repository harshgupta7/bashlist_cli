import click 

@click.command()
def main():
	print("jajajaj")
h