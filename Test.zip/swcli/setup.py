from setuptools import setup 

setup(
	name='Spacewire CLI',
	version='0.5',
	description='Command Line Tools for Spacewire Client',
	author='Sam Crane, Arda Pekis, Kaan Goksal, Harsh Gupta',
	author_email='support@spacewire.io',
	license='(c) Maysquare Inc 2018. All Rights Reserved.',
	install_requires=[
	'click>6.0',
	],
	entry_points='''
		[console_scripts]
		wire=run:main
	''',
)

